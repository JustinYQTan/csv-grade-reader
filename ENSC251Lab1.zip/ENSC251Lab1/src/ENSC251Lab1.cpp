/**
* @file ENSC251Lab1.cpp
* @author Justin Tan
* @date September 16, 2024
* @version 1.0
* @section LA02
*/
// I declare that this assignment is my own work and that I have correctly acknowledged the
// work of others. I acknowledged that I have read and followed the Academic Honesty and
// Integrity related policies as outlined in the syllabus.
//
// _____ (Justin Tan) ____ _____(September 16, 2024)______________
//
// ____ (301556923) ______
//


#include <iostream>
#include <string>
#include <rapidcsv.h>
#include <fstream>
#include <vector>
using namespace std;


double average(int first, int second, int third) {
   return (first + second + third)/3.0;
}

int main() {
   rapidcsv::Document document("grades.csv");
   vector<string> firstNames{document.GetColumn<string>("firstname")};
   vector<string> lastNames{document.GetColumn<string>("lastname")};
   vector<int> exam1grades{document.GetColumn<int>("exam1grade")};
   vector<int> exam2grades{document.GetColumn<int>("exam2grade")};
   vector<int> exam3grades{document.GetColumn<int>("exam3grade")};

   printf("%-25s %-6s %-6s %-6s %-6s\n", "Name", "Exam1", "Exam2", "Exam3", "Avg");
   cout << "-------------------------------------------------------\n";

   for (size_t i{0}; i < firstNames.size(); ++i) {
      double averageresult = average(exam1grades.at(i), exam2grades.at(i), exam3grades.at(i));
      printf("%-25s %-6d %-6d %-6d %-6.2f\n",(firstNames.at(i) + " " + lastNames.at(i)).c_str(),
            exam1grades.at(i), exam2grades.at(i), exam3grades.at(i),averageresult);
   }
  return 0;

}
